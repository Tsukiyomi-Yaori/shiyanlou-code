#!/usr/bin/env python3
from fact import factorial
__all__ = [factorial, ]
